package aula5;

import static utils.Contacts.validateMail;
import static utils.Contacts.validateNumbr;
public class test {
    public static void main(String[] args) {
        System.out.println(validateMail("a@.pt"));
        System.out.println(validateNumbr(987654321));
    }


}