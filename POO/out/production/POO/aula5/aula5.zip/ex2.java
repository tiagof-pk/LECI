package aula5;
import java.util.Scanner;
public class ex2 {
    public static void main(String[] args) {
        int op = 6;
        Scanner sc = new Scanner(System.in);
        beginY calendar = null;
        int year = -1;
        while (op != 0) {
            System.out.println("Calendar operations:\n" +
                    "1 - create new calendar\n" +
                    "2 - print calendar month\n" +
                    "3 - print calendar\n" +
                    "4 - Add Event\n" +
                    "5 - Remove Event\n" +
                    "0 – exit");
            op = sc.nextInt();
            switch (op) {
                case 1:
                    System.out.println("Digite o ano : ");
                    year = sc.nextInt();
                    System.out.println("Digite o dia da semana em que o ano começa (1 a 7)/(Seg a Dom): ");
                    int beginDayYear = sc.nextInt();
                    if (year < 0 || (beginDayYear < 1 || beginDayYear > 7)) {
                        System.out.println("Data inválida! Tente novamente.");
                    } else {
                        calendar = new beginY(year, beginDayYear);
                    }
                    break;
                case 2:
                    if (calendar == null || year == -1) {
                    } else {
                        System.out.print("Digite o mês ( 1--12 ) : ");
                        int month = sc.nextInt();
                        int beginDay = calendar.beginDayMonth(month);
                        calendar.printMonth(month, year, beginDay);
                    }
                    break;
                case 3:
                    if (calendar == null || year == -1) {
                        System.out.println("Pfv crie um calendário.");
                    } else {
                        for (int i = 1; i < 13; i++) {
                            int beginDayMonth = calendar.beginDayMonth(i);
                            calendar.printYear(i, year, beginDayMonth);
                        }
                    }
                    break;
                case 4:
                    System.out.println("Mês do evento-->");
                    int month = sc.nextInt();
                    System.out.println("Dia do evento-->");
                    int day = sc.nextInt();
                    calendar.addEvent(day, month);
                    break;
                case 5:
                    System.out.println("Mês do evento-->");
                    int monthEvent = sc.nextInt();
                    System.out.println("Dia do evento-->");
                    int dayEvent = sc.nextInt();
                    calendar.removeEvent(dayEvent, monthEvent);
                    break;
                case 0:
                    System.out.println("A encerrar programa...");
                    break;
                default:
                    System.out.println("Opção Invalida.");
                    break;
            }
        }
    }
}
class beginY {
    private int year;
    private int beginDayYear;
    public static int[][] events;

    public beginY(int year, int beginDayYear) {
        this.year = year;
        this.beginDayYear = beginDayYear;
        for (int i = 1; i < 13; i++) {
            events = new int[12][DateYMD.monthDays(i, year)];
        }
    }

    public int beginDayMonth(int month) {
        switch (month) {
            case 1:
                return beginDayYear;
            case 2:
                return (beginDayYear + 31) % 7;
            case 3:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29) % 7);
                } else {
                    return ((beginDayYear + 31 + 28) % 7);
                }
            case 4:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31) % 7);
                }
            case 5:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30) % 7);
                }
            case 6:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31) % 7);
                }
            case 7:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30) % 7);
                }
            case 8:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30 + 31) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30 + 31) % 7);
                }
            case 9:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31) % 7);
                }
            case 10:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30) % 7);
                }
            case 11:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31) % 7);
                }
            case 12:
                if (DateYMD.leapYear(year)) {
                    return ((beginDayYear + 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30) % 7);
                } else {
                    return ((beginDayYear + 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30) % 7);
                }
            default:
                return 0;
        }
    }

    public void addEvent(int day, int month) {
        events[month - 1][day - 1]++;
    }

    public void removeEvent(int day, int month) {
        events[month - 1][day - 1]--;
    }

    public static void printMonth(int month, int year, int beginDay) {
        String[] monthLST = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
        System.out.println("  " + monthLST[month - 1] + "/" + year);
        System.out.println("Su Mo Tu We Th Fr Sa");
        int diasNoMes = DateYMD.monthDays(month, year);
        for (int i = 0; i < beginDay; i++) {
            if (beginDay != 7) {
                System.out.print("   ");
            }
        }
        for (int i = 1; i <= diasNoMes; i++) {
            if (events[month - 1][i - 1] == 0) {
                System.out.printf("%2d ", i);
            } else {
                System.out.printf("%s%2d ", "*", i);
            }
            if ((i + beginDay) % 7 == 0 || i == diasNoMes) {
                System.out.println();
            }
        }
    }

    public static void printYear(int month, int year, int beginDay) {
        printMonth(month, year, beginDay);

    }

    public int getYear() {
        return this.year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getBeginDayYear() {
        return this.beginDayYear;
    }

    public void setBeginDayYear(int beginDayYear) {
        this.beginDayYear = beginDayYear;
    }
}