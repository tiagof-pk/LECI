package aula5;

public class Ex3 {
    public static void main(String[] args) {
        RealEstate imobiliaria = new RealEstate();
        imobiliaria.newProperty("Glória", 2, 30000);
        imobiliaria.newProperty("Vera Cruz", 1, 25000);
        imobiliaria.newProperty("Santa Joana", 3, 32000);
        imobiliaria.newProperty("Aradas", 2, 24000);
        imobiliaria.newProperty("São Bernardo", 2, 20000);

        imobiliaria.sell(1001);
        imobiliaria.setAuction(1002, new DateYMD(21, 3, 2023), 4);
        imobiliaria.setAuction(1003, new DateYMD(1, 4, 2023), 3);
        imobiliaria.setAuction(1001, new DateYMD(1, 4, 2023), 4);
        imobiliaria.setAuction(1010, new DateYMD(1, 4, 2023), 4);

        System.out.println(imobiliaria);
    }
}

class RealEstate{
    private final boolean free;
    private int count;
    private DateYMD date;
    private DateYMD end;
    private int c;
    private String[][] imoveis;
    private String[][] datas;

    public RealEstate(){
        this.free = false;
        this.imoveis = new String[5][5];
        this.datas = new String[5][2];
        this.count = 1000;
        this.c = 0;
        for (int i = 0; i < imoveis.length; i++) {
            for (int j = 0; j < imoveis[i].length; j++) {
                imoveis[i][j] = "";
            }
            imoveis[i][4] = "SIM";
        }
    }

    public void newProperty(String local, int rooms, int price){
        imoveis[c] = new String[]{Integer.toString(count), local, Integer.toString(rooms), Integer.toString(price), "SIM"};
        count++;
        c++;
        }


    public void sell(int numbr){
        String id = Integer.toString(numbr);
        for (int i = 0; i < imoveis.length; i++) {

            if (id.equals(imoveis[i][0])) {
                imoveis[i][4] = "NÃO";
                System.out.println("Imovel "+ numbr +" vendido");
            }
        }

    }

    public void setAuction(int numbr , DateYMD date ,int duration) {
        String id = Integer.toString(numbr);
        for (int j = 0; j < 5; j++) {
            if ((id == imoveis[j][0]) && (imoveis[j][4] == "NÃO")) {
                System.out.println("Imóvel " + numbr + " não está disponível.");
                break;

            }
        }
        if ((numbr < 1000 || numbr > 1004)) {
            System.out.println("Imóvel " + numbr + " não existe.");
        }
        else {
            this.date = date;
            this.end = date;
            datas[numbr - 1000][0] = date.toString();
            for (int i = 0; i < duration; i++) {
                end.increment();
            }
            datas[numbr - 1000][1] = end.toString();
        }

    }


    public String toString(){
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            if (datas[i][0] != null && imoveis[i][4] != "NÃO") {
                sb.append(String.format("Imovel:%s; Quartos:%s; Localidade:%s; Preço:%s; Disponível:%s; %s : %s%n", imoveis[i][0], imoveis[i][2], imoveis[i][1], imoveis[i][3], imoveis[i][4], datas[i][0], datas[i][1]));
            }
            else{
                sb.append(String.format("Imovel:%s; Quartos:%s; Localidade:%s; Preço:%s; Disponível:%s;%n", imoveis[i][0], imoveis[i][2], imoveis[i][1], imoveis[i][3], imoveis[i][4]));

            }
        }
        return sb.toString();
    }
}
